var Abhay = artifacts.require("./Aby.sol");

module.exports = function(deployer) {
  deployer.deploy(Abhay);
};